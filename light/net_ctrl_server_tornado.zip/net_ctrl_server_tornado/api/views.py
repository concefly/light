# -*- coding:utf-8 -*-

import tornado.web

import json
import datetime
import db_access as db

def convertDatetime(obj):
	return obj.strftime('%Y-%m-%d T %H:%M:%S')

class group_online(tornado.web.RequestHandler):
	#~ 无请求值：返回所有记录
	def get(self):
		res = []
		groups = db.GroupOnline.selectBy();
		for group in groups:
			d = {}
			d['zaddr'] = group.zaddr
			d['ChipCode'] = group.ChipCode
			d['DevCount'] = group.DevCount
			d['time'] = convertDatetime(group.time)
			res.append(d)
		self.write(json.dumps(res))
	
	def post(self):
		self.get()

class group_fix_info(tornado.web.RequestHandler):
	#~ 无请求值：返回所有记录
	def get(self):
		res = []
		groups = db.GroupFixInfo.selectBy()
		for group in groups:
			d = {}
			d['zaddr'] = group.zaddr
			d['name'] = group.name
			d['describe'] = group.describe
			res.append(d)
		self.write(json.dumps(res))
	
	def post(self):
		self.get()

class group_var_info(tornado.web.RequestHandler):
	#~ 无请求值：返回所有记录
	#~ zaddr, ... 请求：修改并返回所有记录
	def get(self):
		req = self.request.arguments.copy()
		if req.has_key('zaddr'):
			#~ zaddr, ... 请求
			req_zaddr = int(req.pop('zaddr')[0])
			groups = db.GroupVarInfo.selectBy(zaddr=req_zaddr);
			if len(list(groups))==0:
				InitValue = {}
				InitValue['zaddr'] = req_zaddr
				for k in req:
					if k=='name':
						InitValue['name'] = req['name'][0]
					elif k=='describe':
						InitValue['describe'] = req['describe'][0]
				group = db.GroupVarInfo(**InitValue)
			else:
				group = groups[0]
				group.set(name=req['name'][0], describe=req['describe'][0])
		#~ 返回所有记录
		groups = db.GroupVarInfo.selectBy()
		res = []
		for group in groups:
			d = {}
			d['zaddr'] = group.zaddr
			d['name'] = group.name
			d['describe'] = group.describe
			res.append(d)
		self.write(json.dumps(res))
	
	def post(self):
		self.get()

class dev_online(tornado.web.RequestHandler):
	#~ 无请求值：返回所有记录
	def get(self):
		res = []
		devs = db.DevOnline.selectBy();
		for dev in devs:
			d = {}
			d['zaddr'] = dev.zaddr
			d['id'] = dev.did
			d['MajorNum'] = dev.MajorNum
			d['SubNum'] = dev.SubNum
			res.append(d)
		self.write(json.dumps(res))
	
	def post(self):
		self.get()

class dev_fix_info(tornado.web.RequestHandler):
	#~ 无请求值：返回所有记录
	def get(self):
		res = []
		devs = db.DevFixInfo.selectBy()
		for dev in devs:
			d = {}
			d['zaddr'] = dev.zaddr
			d['id'] = dev.did
			d['name'] = dev.name
			d['describe'] = dev.describe
			res.append(d)
		self.write(json.dumps(res))
	
	def post(self):
		self.get()

class dev_var_info(tornado.web.RequestHandler):
	#~ 无请求值：返回所有记录
	#~ zaddr,id ... 请求：修改并返回所有记录
	def get(self):
		req = self.request.arguments.copy()
		if req.has_key('zaddr') and req.has_key('id'):
			#~ zaddr,id ... 请求
			req_zaddr = int(req.pop('zaddr')[0])
			req_id = int(req.pop('id')[0])
			devs = db.DevVarInfo.selectBy(zaddr=req_zaddr,did=req_id);
			if len(list(devs))==0:
				InitValue = {}
				InitValue['zaddr'] = req_zaddr
				InitValue['did'] = req_id
				for k in req:
					if k=='name':
						InitValue['name'] = req['name'][0]
					elif k=='describe':
						InitValue['describe'] = req['describe'][0]
				dev = db.DevVarInfo(**InitValue)
			else:
				dev = devs[0]
				dev.set(name=req['name'][0], describe=req['describe'][0])
		#~ 返回所有记录
		devs = db.DevVarInfo.selectBy()
		res = []
		for dev in devs:
			d = {}
			d['zaddr'] = dev.zaddr
			d['id'] = dev.did
			d['name'] = dev.name
			d['describe'] = dev.describe
			res.append(d)
		self.write(json.dumps(res))
	
	def post(self):
		self.get()

class dev_dyn00(tornado.web.RequestHandler):
	#~ limit 请求：返回limit记录
	#~ zaddr, id, datDict{light:Integer}, limit 请求：添加记录，返回limit记录
	def get(self):
		req = self.request.arguments.copy()
		req_limit = int(req.pop('limit')[0])
		#~ 
		if req.has_key('zaddr') and req.has_key('id'):
			#~ 添加记录
			InitValue = {}
			InitValue['zaddr'] = int(req.pop('zaddr')[0])
			InitValue['did'] = int(req.pop('id')[0])
			for k in req:
				if k=='light':
					InitValue[k] = int(req[k][0])
			db.DevDyn00(**InitValue)
		res = []
		devs = db.DevDyn00.select(orderBy=['-time'])
		devs = devs[:req_limit]
		for dev in devs:
			d = {}
			d['zaddr'] = dev.zaddr
			d['id'] = dev.did
			d['time'] = convertDatetime(dev.time)
			d['light'] = dev.light
			res.append(d)
		self.write(json.dumps(res))
	
	def post(self):
		self.get()

class dev_dyn01(tornado.web.RequestHandler):
	#~ limit 请求：返回limit记录
	def get(self):
		req = self.request.arguments.copy()
		req_limit = int(req.pop('limit')[0])
		#~ 
		if req.has_key('zaddr') and req.has_key('id'):
			#~ 添加记录
			InitValue = {}
			InitValue['zaddr'] = int(req.pop('zaddr')[0])
			InitValue['did'] = int(req.pop('id')[0])
			for k in req:
				if k=='light':
					InitValue[k] = int(req[k][0])
			db.DevDyn01(**InitValue)
		res = []
		devs = db.DevDyn01.select(orderBy=['-time'])
		devs = devs[:req_limit]
		for dev in devs:
			d = {}
			d['zaddr'] = dev.zaddr
			d['id'] = dev.did
			d['time'] = convertDatetime(dev.time)
			d['light'] = dev.light
			res.append(d)
		self.write(json.dumps(res))
	
	def post(self):
		self.get()
