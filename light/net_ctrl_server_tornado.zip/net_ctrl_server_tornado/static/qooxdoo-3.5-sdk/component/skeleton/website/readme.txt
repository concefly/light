WEBSITE Skeleton - A qooxdoo Application Template
=================================================

This skeleton application was created by running the 'create-application.py'
script. You usually will want to run

  ./generate.py

in this directory first thing. For more information about how to use this 
skeleton, please refer to the 'skeleton' section in the manual.

You can safely replace the entire contents of this file with your own 
documentation.

# The following is only required during execution of 'create-application.py'
short:: can be used to build low-level qooxdoo applications
copy_file:: component/standalone/website/script/q.js  script/q-3.5.js
copy_file:: component/standalone/website/script/q.min.js  script/q-3.5.min.js
