Your qooxdoo Contribution
=========================

This is a qooxdoo contribution skeleton which is used as a template. The
'create-application.py' script (usually under tool/bin/create-application.py)
will use this and expand it into a self-contained qooxdoo contribution which can
then be further extended. Please refer to the script and other documentation for
further information.

Please use the provided application inside the 'demo' folder to test your
contribution.

short:: is suitable for qooxdoo-contrib
copy_file:: tool/data/generator/needs_generation.js demo/default/source/script/custom.demo.js
