qx.Website Widgets - Browser App
