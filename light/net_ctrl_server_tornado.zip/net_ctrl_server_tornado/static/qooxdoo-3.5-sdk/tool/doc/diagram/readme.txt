code_generation_classes.graphml			-- class diagram for classes used in code generation
compile_calls1.graphml	-- call graph for compiler entries, module oriented
compile_calls2.graphml	-- call graph for compiler entries, method oriented