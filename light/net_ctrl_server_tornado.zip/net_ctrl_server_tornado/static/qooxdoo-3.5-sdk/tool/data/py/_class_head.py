##                                                                              
# Some nice short description of class Foo
#                                                                               
# @param Super The super-class of Foo
