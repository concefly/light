Version: 24

We only use this part: core.zip:common/main

Official CLDR page:
http://cldr.unicode.org/
