
qx.Class.define('monitor.TextForm'
{
	
});
